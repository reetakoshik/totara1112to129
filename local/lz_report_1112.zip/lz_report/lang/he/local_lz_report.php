<?php

$string['pluginname'] = 'דוחות נוספים Learning Zone';
$string['menu-item-name'] = 'דוחות Learning Zone';
$string['lz_report:viewemlzbedded'] = 'צפב בדוח מוטמע';