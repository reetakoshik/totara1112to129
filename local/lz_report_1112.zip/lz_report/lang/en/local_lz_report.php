<?php

$string['pluginname'] = 'Learning Zone Additional Reports';
$string['menu-item-name'] = 'Learning Zone reports';
$string['lz_report:viewemlzbedded'] = 'View embedded report';