<?php

$string['sourcetitle'] = 'Detailed Activity Completion Report';
$string['type_activity_completion'] = 'Actity completion';
$string['type_module'] = 'Activity';
$string['type_module_completion'] = 'Activity completion';
$string['type_course_completion'] = 'Course completion';
$string['moduletitle'] = 'Activity title';
$string['moduletype'] = 'Activity type';
$string['completionstate'] = 'Completion status';
$string['timecompleted'] = 'Completion date';