<?php

$string['sourcetitle'] = 'Resources/Activities';
// Columns.
$string['name'] = 'Name';
$string['link'] = 'Link';
$string['summary'] = 'Summary';
$string['type'] = 'Type';
$string['icon'] = 'Icon';
$string['cmadded'] = 'Time Created';
$string['timemodified'] = 'Time Modified';
$string['coursefullname'] = 'Course Full Name';
$string['courselink'] = 'Course Link';
$string['courseshortname'] = 'Course Short Name';
$string['courseid'] = 'Course Id';
$string['coursecategory'] = 'Course Category';
$string['enrollment'] = 'Enrollment';
$string['enrolled'] = 'Enrolled';
$string['notenrolled'] = 'Not Enrolled';

$string['type_activity'] = 'Activity';
// Filters.


// Content.
