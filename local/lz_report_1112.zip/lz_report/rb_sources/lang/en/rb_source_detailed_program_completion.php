<?php

$string['sourcetitle'] = 'Program and Certification Detailed Completion';
$string['type_certif'] = 'Certification';
$string['type_progcompletion'] = 'Program/Certification Completion';
$string['empty-message'] = 'No courses required to complete';
$string['not-applicable'] = 'Not applicable';
$string['type'] = 'Type';
$string['details'] = 'Status bar with detailed progress';
$string['finalstatus'] = 'Final Status';