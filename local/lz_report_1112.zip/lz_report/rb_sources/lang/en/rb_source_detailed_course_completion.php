<?php

$string['sourcetitle'] = 'Detailed Course Completion Report';
$string['type_course_completion'] = 'Course Completion';

$string['form-header'] = 'Show by user role in the course';
$string['form-checkbox'] = 'Show completion records from courses in which the user viewing the report has the following role/s:';
$string['form-checkbox_help'] = 'Enable';
$string['empty-message'] = 'No activities required to complete';

$string['completion-requirements'] = 'Course completion requirements';
