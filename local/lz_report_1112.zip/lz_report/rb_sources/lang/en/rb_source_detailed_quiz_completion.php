<?php

$string['sourcetitle'] = 'Detailed quiz completion';
$string['type_quiz_attempt'] = 'Quiz attempts';
$string['type_quiz'] = 'Quiz';
$string['quiz_id'] = 'Quiz Id';
$string['quiz_title'] = 'Quiz Title';
$string['quiz_attempt_id'] = 'Quiz Attempt Id';
$string['quiz_attempt_number'] = 'Quiz Attempt Number';
$string['quiz_attempt_state'] = 'Quiz Attempt State';
$string['quiz_attempt_sumgrades'] = 'Quiz Grade';
$string['quiz_attempt_timestart'] = 'Quiz Attempt Start';
$string['quiz_attempt_timefinish'] = 'Quiz Attempt Finish';
$string['quiz_attempt_duration'] = 'Quiz Attempt Duration';