<?php

$string['sourcetitle'] = 'השלמת מסלולים והסמכות מפורט';
$string['type_certif'] = 'הסמכה';
$string['type_progcompletion'] = 'השלמת מסלול/הסמכה';
$string['empty-message'] = 'אין קורסים הנדרשים להשלמה';
$string['not-applicable'] = 'לא רלוונטי';
$string['type'] = 'סוג רשומה';
$string['details'] = 'בר סטטוס השלמה עם פירוט התקדמות';
$string['finalstatus'] = 'Final Status';