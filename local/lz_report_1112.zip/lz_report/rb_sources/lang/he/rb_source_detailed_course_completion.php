<?php

$string['sourcetitle'] = 'השלמת קורס מפורט';
$string['type_course_completion'] = 'השלמת קורס';

$string['form-header'] = 'הצג משתמשים לפי תפקיד';
$string['form-checkbox'] = 'הצג רשומות השלמה מקורסים בהם המשתמש הצופה בדוח הוא בעל התפקיד/ים הבאים:';
$string['form-checkbox_help'] = 'הפעל';
$string['empty-message'] = 'לא נדרשות פעילויות להשלמה';

$string['completion-requirements'] = 'תנאים נדרשים להשלמת הקורס';