<?php

$string['sourcetitle'] = 'חיפוש פעילויות למידה';
// Columns.
$string['name'] = 'שם';
$string['link'] = 'קישור';
$string['summary'] = 'תקציר';
$string['type'] = 'סוג';
$string['icon'] = 'סמליל';
$string['cmadded'] = 'זמן היצירה';
$string['timemodified'] = 'זמן העריכה';
$string['coursefullname'] = 'שם מלא של הקורס';
$string['courselink'] = 'קישור לקורס';
$string['courseshortname'] = 'שם קצר של הקורס';
$string['courseid'] = 'מזהה הקורס';
$string['coursecategory'] = 'קטיגוריית הקורס';
$string['enrollment'] = 'סטטוס רישום';
$string['enrolled'] = 'רשום';
$string['notenrolled'] = 'לא רשום';

$string['type_activity'] = 'פעילות';
// Filters.



// Content.
