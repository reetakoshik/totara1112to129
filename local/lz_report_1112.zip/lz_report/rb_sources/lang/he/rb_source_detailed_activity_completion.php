<?php

$string['sourcetitle'] = 'השלמת פעילות מפורט';
$string['type_activity_completion'] = 'השלמת פעילות';
$string['type_module'] = 'פעילות';
$string['type_module_completion'] = 'השלמת פעילות';
$string['type_course_completion'] = 'השלמת קורס';
$string['moduletitle'] = 'כותרת הפעילות';
$string['moduletype'] = 'סוג הפעילות';
$string['completionstate'] = 'סטטוס השלמה';
$string['timecompleted'] = 'תאריך השלמה';