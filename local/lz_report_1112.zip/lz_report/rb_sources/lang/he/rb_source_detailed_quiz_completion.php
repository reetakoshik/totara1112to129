<?php

$string['sourcetitle'] = 'ניסיונות מענה מבחנים';
$string['type_quiz_attempt'] = 'ניסיונות מענה מבחנים';
$string['type_quiz'] = 'מבחן';
$string['quiz_id'] = 'קוד זיהוי המבחן';
$string['quiz_title'] = 'כותרת המבחן';
$string['quiz_attempt_id'] = 'קוד זיהוי הניסיון של המבחן';
$string['quiz_attempt_number'] = 'מספר הניסיון של המשתמש במבחן';
$string['quiz_attempt_state'] = 'סטטוס הניסיון של המשתמש';
$string['quiz_attempt_sumgrades'] = 'ציון במבחן';
$string['quiz_attempt_timestart'] = 'מועד התחלת הניסיון';
$string['quiz_attempt_timefinish'] = 'מועד סיום הניסיון';
$string['quiz_attempt_duration'] = 'משך הניסיון במבחן';