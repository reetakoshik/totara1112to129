<?php

$plugin->version  = 2019021901;
$plugin->requires = 2016112900; 
$plugin->cron     = 0;
$plugin->release = '1.1 (Build: 2017041901)';
$plugin->maturity = MATURITY_STABLE;
$plugin->component = 'local_lz_report';