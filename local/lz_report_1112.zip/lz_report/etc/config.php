<?php

define('VIEW_LZ_REPORT_CAPABILITY', 'local/lz_report:viewemlzbedded');