"use strict";

const ScormPackage_Value = {
    "token": "-------customer-token-------",
    "version": "1.2",
    "id": 1916572
};
